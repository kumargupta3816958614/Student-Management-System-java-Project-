package com.studentmanagement;

public class Student extends Person {
    private int id;
    private String rollNo;
    private String course;
    private int semester;

    public Student(int id, String rollNo, String name, String email, String course, int semester) {
        super(name, email);
        this.id = id;
        this.rollNo = rollNo;
        this.course = course;
        this.semester = semester;
    }

    public Student(String rollNo, String name, String email, String course, int semester) {
        this(0, rollNo, name, email, course, semester);
    }

    public int getId() { return id; }
    public String getRollNo() { return rollNo; }
    public String getName() { return name; }
    public String getEmail() { return email; }
    public String getCourse() { return course; }
    public int getSemester() { return semester; }
    @Override public String getRole() { return "Student"; }
}
