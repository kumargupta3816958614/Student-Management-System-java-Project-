package com.studentmanagement;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class StudentServiceImpl implements StudentService {
    @Override
    public void addStudent(Student s) throws Exception {
        String sql = "INSERT INTO students(roll_no,name,email,course,semester) VALUES(?,?,?,?,?)";
        try (Connection con = Database.getConnection(); PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setString(1, s.getRollNo());
            ps.setString(2, s.getName());
            ps.setString(3, s.getEmail());
            ps.setString(4, s.getCourse());
            ps.setInt(5, s.getSemester());
            ps.executeUpdate();
        }
    }

    @Override
    public List<Student> getAllStudents() throws Exception {
        List<Student> list = new ArrayList<>();
        String sql = "SELECT * FROM students ORDER BY id DESC";
        try (Connection con = Database.getConnection();
             Statement st = con.createStatement(); ResultSet rs = st.executeQuery(sql)) {
            while (rs.next()) list.add(mapStudent(rs));
        }
        return list;
    }

    @Override
    public List<Student> searchStudents(String keyword) throws Exception {
        List<Student> list = new ArrayList<>();
        String sql = "SELECT * FROM students WHERE roll_no LIKE ? OR name LIKE ? ORDER BY name";
        try (Connection con = Database.getConnection(); PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setString(1, "%" + keyword + "%");
            ps.setString(2, "%" + keyword + "%");
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) list.add(mapStudent(rs));
            }
        }
        return list;
    }

    @Override
    public void updateStudent(Student s) throws Exception {
        String sql = "UPDATE students SET roll_no=?, name=?, email=?, course=?, semester=? WHERE id=?";
        try (Connection con = Database.getConnection(); PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setString(1, s.getRollNo());
            ps.setString(2, s.getName());
            ps.setString(3, s.getEmail());
            ps.setString(4, s.getCourse());
            ps.setInt(5, s.getSemester());
            ps.setInt(6, s.getId());
            if (ps.executeUpdate() == 0) throw new Exception("Student record was not found.");
        }
    }

    @Override
    public void deleteStudent(int id) throws Exception {
        try (Connection con = Database.getConnection();
             PreparedStatement ps = con.prepareStatement("DELETE FROM students WHERE id=?")) {
            ps.setInt(1, id);
            ps.executeUpdate();
        }
    }

    private Student mapStudent(ResultSet rs) throws SQLException {
        return new Student(rs.getInt("id"), rs.getString("roll_no"), rs.getString("name"),
                rs.getString("email"), rs.getString("course"), rs.getInt("semester"));
    }
}
