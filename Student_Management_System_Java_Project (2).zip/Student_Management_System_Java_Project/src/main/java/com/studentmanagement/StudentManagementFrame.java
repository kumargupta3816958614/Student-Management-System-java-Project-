package com.studentmanagement;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.util.List;

public class StudentManagementFrame extends JFrame {

    private final StudentService service = new StudentServiceImpl();

    // Input fields
    private final JTextField rollField = new JTextField(18);
    private final JTextField nameField = new JTextField(18);
    private final JTextField emailField = new JTextField(18);
    private final JTextField courseField = new JTextField(18);
    private final JTextField semesterField = new JTextField(18);
    private final JTextField searchField = new JTextField(18);

    // Table
    private final DefaultTableModel model = new DefaultTableModel(
        new String[]{"ID", "Roll No", "Name", "Email", "Course", "Semester"}, 0
    ) {
        @Override
        public boolean isCellEditable(int row, int column) {
            return false;
        }
    };

    private final JTable table = new JTable(model);

    private int selectedId = -1;

    public StudentManagementFrame() {

        setTitle("Student Management System");
        setSize(950, 700);
        setMinimumSize(new Dimension(800, 600));
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        buildUI();
        loadStudents();
    }

    // Main GUI
    private void buildUI() {

        setLayout(new BorderLayout(10, 10));

        // Heading
        JLabel heading = new JLabel(
            "STUDENT MANAGEMENT SYSTEM",
            SwingConstants.CENTER
        );

        heading.setFont(new Font("Arial", Font.BOLD, 25));
        heading.setForeground(new Color(28, 65, 120));
        heading.setBorder(
            BorderFactory.createEmptyBorder(18, 5, 18, 5)
        );

        add(heading, BorderLayout.NORTH);

        // Student Details Form
        JPanel form = new JPanel(new GridBagLayout());

        form.setBorder(
            BorderFactory.createTitledBorder("Student Details")
        );

        GridBagConstraints g = new GridBagConstraints();

        g.insets = new Insets(7, 10, 7, 10);
        g.fill = GridBagConstraints.HORIZONTAL;

        addField(form, g, 0, "Roll Number:", rollField);
        addField(form, g, 1, "Full Name:", nameField);
        addField(form, g, 2, "Email:", emailField);
        addField(form, g, 3, "Course:", courseField);
        addField(form, g, 4, "Semester:", semesterField);

        // Buttons
        JPanel buttons = new JPanel(
            new FlowLayout(FlowLayout.CENTER, 10, 10)
        );

        JButton addButton = new JButton("Add Student");
        JButton updateButton = new JButton("Update Selected");
        JButton deleteButton = new JButton("Delete Selected");
        JButton clearButton = new JButton("Clear");

        buttons.add(addButton);
        buttons.add(updateButton);
        buttons.add(deleteButton);
        buttons.add(clearButton);

        // Top panel contains form and buttons
        JPanel topPanel = new JPanel(new BorderLayout(5, 5));

        topPanel.add(form, BorderLayout.CENTER);
        topPanel.add(buttons, BorderLayout.SOUTH);

        // Search Panel
        JPanel searchPanel = new JPanel(
            new FlowLayout(FlowLayout.LEFT, 10, 10)
        );

        searchPanel.setBorder(
            BorderFactory.createTitledBorder("Search Students")
        );

        JButton searchButton = new JButton("Search");
        JButton showAllButton = new JButton("Show All");

        searchPanel.add(new JLabel("Name / Roll Number:"));
        searchPanel.add(searchField);
        searchPanel.add(searchButton);
        searchPanel.add(showAllButton);

        // Student Table
        table.setRowHeight(28);
        table.setSelectionMode(
            ListSelectionModel.SINGLE_SELECTION
        );

        JScrollPane scrollPane = new JScrollPane(table);

        // Search and table panel
        JPanel tablePanel = new JPanel(new BorderLayout(5, 5));

        tablePanel.add(searchPanel, BorderLayout.NORTH);
        tablePanel.add(scrollPane, BorderLayout.CENTER);

        // Main center panel
        JPanel centerPanel = new JPanel(new BorderLayout(10, 10));

        centerPanel.setBorder(
            BorderFactory.createEmptyBorder(5, 10, 10, 10)
        );

        centerPanel.add(topPanel, BorderLayout.NORTH);
        centerPanel.add(tablePanel, BorderLayout.CENTER);

        add(centerPanel, BorderLayout.CENTER);

        // Button Events
        addButton.addActionListener(e -> addStudent());

        updateButton.addActionListener(e -> updateStudent());

        deleteButton.addActionListener(e -> deleteStudent());

        clearButton.addActionListener(e -> clearForm());

        searchButton.addActionListener(e -> searchStudents());

        showAllButton.addActionListener(e -> loadStudents());

        // Table Selection Event
        table.getSelectionModel().addListSelectionListener(e -> {

            if (!e.getValueIsAdjusting()
                    && table.getSelectedRow() >= 0) {

                fillFormFromSelection();
            }
        });
    }

    // Add labels and text fields
    private void addField(
        JPanel panel,
        GridBagConstraints g,
        int row,
        String label,
        JTextField field
    ) {

        g.gridy = row;
        g.gridx = 0;
        g.weightx = 0;

        panel.add(new JLabel(label), g);

        g.gridx = 1;
        g.weightx = 1;

        panel.add(field, g);
    }

    // Read and validate student details
    private Student readForm(int id) throws ValidationException {

        String roll = rollField.getText().trim();
        String name = nameField.getText().trim();
        String email = emailField.getText().trim();
        String course = courseField.getText().trim();
        String semText = semesterField.getText().trim();

        if (roll.isEmpty() || name.isEmpty()
                || email.isEmpty() || course.isEmpty()
                || semText.isEmpty()) {

            throw new ValidationException(
                "Please fill in all fields."
            );
        }

        if (!email.matches("^[A-Za-z0-9+_.-]+@[A-Za-z0-9.-]+$")) {

            throw new ValidationException(
                "Please enter a valid email address."
            );
        }

        try {

            int semester = Integer.parseInt(semText);

            if (semester < 1 || semester > 12) {

                throw new ValidationException(
                    "Semester must be between 1 and 12."
                );
            }

            return new Student(
                id, roll, name, email, course, semester
            );

        } catch (NumberFormatException ex) {

            throw new ValidationException(
                "Semester must be a number."
            );
        }
    }

    // Add Student
    private void addStudent() {

        try {

            service.addStudent(readForm(0));

            JOptionPane.showMessageDialog(
                this, "Student added successfully!"
            );

            clearForm();
            loadStudents();

        } catch (ValidationException ex) {

            showError(ex.getMessage());

        } catch (Exception ex) {

            showError(
                "Could not add student. Check whether the roll number already exists.\n"
                + ex.getMessage()
            );
        }
    }

    // Update Student
    private void updateStudent() {

        if (selectedId < 0) {

            showError("Please select a student from the table first.");
            return;
        }

        try {

            service.updateStudent(readForm(selectedId));

            JOptionPane.showMessageDialog(
                this, "Student updated successfully!"
            );

            clearForm();
            loadStudents();

        } catch (Exception ex) {

            showError(ex.getMessage());
        }
    }

    // Delete Student
    private void deleteStudent() {

        if (selectedId < 0) {

            showError("Please select a student first.");
            return;
        }

        int choice = JOptionPane.showConfirmDialog(
            this,
            "Are you sure you want to delete this student?",
            "Confirm Delete",
            JOptionPane.YES_NO_OPTION
        );

        if (choice == JOptionPane.YES_OPTION) {

            try {

                service.deleteStudent(selectedId);

                JOptionPane.showMessageDialog(
                    this, "Student deleted successfully!"
                );

                clearForm();
                loadStudents();

            } catch (Exception ex) {

                showError(ex.getMessage());
            }
        }
    }

    // Search Students
    private void searchStudents() {

        String keyword = searchField.getText().trim();

        new SwingWorker<List<Student>, Void>() {

            @Override
            protected List<Student> doInBackground() throws Exception {

                return service.searchStudents(keyword);
            }

            @Override
            protected void done() {

                try {

                    displayStudents(get());

                } catch (Exception ex) {

                    showError("Search failed: " + ex.getMessage());
                }
            }

        }.execute();
    }

    // Load All Students
    private void loadStudents() {

        new SwingWorker<List<Student>, Void>() {

            @Override
            protected List<Student> doInBackground() throws Exception {

                return service.getAllStudents();
            }

            @Override
            protected void done() {

                try {

                    displayStudents(get());

                } catch (Exception ex) {

                    showError(
                        "Could not load records: " + ex.getMessage()
                    );
                }
            }

        }.execute();
    }

    // Display records in table
    private void displayStudents(List<Student> students) {

        model.setRowCount(0);

        for (Student s : students) {

            model.addRow(new Object[]{
                s.getId(),
                s.getRollNo(),
                s.getName(),
                s.getEmail(),
                s.getCourse(),
                s.getSemester()
            });
        }
    }

    // Fill form when table row is selected
    private void fillFormFromSelection() {

        int row = table.getSelectedRow();

        selectedId = (int) model.getValueAt(row, 0);

        rollField.setText(model.getValueAt(row, 1).toString());
        nameField.setText(model.getValueAt(row, 2).toString());
        emailField.setText(model.getValueAt(row, 3).toString());
        courseField.setText(model.getValueAt(row, 4).toString());
        semesterField.setText(model.getValueAt(row, 5).toString());
    }

    // Clear all fields
    private void clearForm() {

        rollField.setText("");
        nameField.setText("");
        emailField.setText("");
        courseField.setText("");
        semesterField.setText("");
        searchField.setText("");

        selectedId = -1;

        table.clearSelection();
    }

    // Show Error Message
    private void showError(String message) {

        JOptionPane.showMessageDialog(
            this,
            message,
            "Notice",
            JOptionPane.ERROR_MESSAGE
        );
    }
}