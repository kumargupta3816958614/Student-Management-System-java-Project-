package com.studentmanagement;

public class ValidationException extends Exception {
    public ValidationException(String message) {
        super(message);
    }
}
