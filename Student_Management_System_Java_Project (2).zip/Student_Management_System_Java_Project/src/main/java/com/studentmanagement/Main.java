package com.studentmanagement;

import javax.swing.SwingUtilities;
import javax.swing.JOptionPane;

public class Main {
    public static void main(String[] args) {
        try {
            Database.initialize();
            SwingUtilities.invokeLater(() -> new StudentManagementFrame().setVisible(true));
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Could not start application: " + e.getMessage(),
                    "Startup Error", JOptionPane.ERROR_MESSAGE);
        }
    }
}
