package com.studentmanagement;

import java.util.List;

public interface StudentService {
    void addStudent(Student student) throws Exception;
    List<Student> getAllStudents() throws Exception;
    List<Student> searchStudents(String keyword) throws Exception;
    void updateStudent(Student student) throws Exception;
    void deleteStudent(int id) throws Exception;
}
