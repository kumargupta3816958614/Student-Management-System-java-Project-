# PROJECT REPORT
## Student Management System using Java

### 1. Introduction
The Student Management System is a desktop application developed using Java. It helps store, view, search, update and delete student information in a structured database.

### 2. Objectives
- To understand object-oriented programming in Java.
- To create a graphical user interface using Swing.
- To connect a Java application to a database using JDBC.
- To perform basic database operations (CRUD).
- To handle invalid input and runtime errors.

### 3. Software Requirements
- Java Development Kit (JDK) 17 or later
- Visual Studio Code
- Maven
- SQLite database and SQLite JDBC driver

### 4. Modules
1. Student details form
2. Add student record
3. View all records
4. Search student
5. Update student record
6. Delete student record
7. Database connectivity

### 5. Java Concepts Used
- Classes, objects, constructors and methods
- Encapsulation and inheritance
- Abstract class and method overriding
- Interface implementation
- Exception handling and custom exception
- Swing components and event handling
- SwingWorker for background database operations
- JDBC Connection, PreparedStatement and ResultSet

### 6. Database Design
Table: `students`

| Field | Type | Description |
|---|---|---|
| id | INTEGER | Primary key, auto-increment |
| roll_no | TEXT | Unique student roll number |
| name | TEXT | Student name |
| email | TEXT | Student email |
| course | TEXT | Course name |
| semester | INTEGER | Semester number |

### 7. Working
The user enters student details in the form and selects Add Student. The application validates the input and uses JDBC PreparedStatement to save the record in SQLite. The table displays saved records. A selected record can be updated or deleted. Search finds records by name or roll number.

### 8. Conclusion
This project demonstrates how Java concepts can be combined to build a useful desktop application. It provides practical experience with Swing, OOP, exception handling and JDBC.

### 9. Future Scope
- Add user login
- Add attendance and marks management
- Export student records to PDF or Excel
- Add role-based access for administrator and teacher
