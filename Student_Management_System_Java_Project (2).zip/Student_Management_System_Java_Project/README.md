# Student Management System (Java)

A beginner-friendly desktop project using Java Swing, JDBC and SQLite.

## Requirements
- JDK 17 or later
- Maven 3.8 or later
- VS Code with Extension Pack for Java (recommended)

## Run in VS Code
1. Extract this ZIP.
2. Open the `StudentManagementSystem` folder in VS Code.
3. Allow Maven to download the SQLite JDBC dependency (internet is needed once).
4. Open `src/main/java/com/studentmanagement/Main.java`.
5. Click **Run** above the `main` method.

The application creates `students.db` automatically in the project working directory on first run.

## Features
- Add, view, update and delete student records
- Search by student name or roll number
- Input validation and error handling
- SQLite database storage using JDBC
- Swing graphical interface

## Important
A roll number must be unique. Semester must be between 1 and 12. Do not delete `students.db` if you want to keep your saved records.
